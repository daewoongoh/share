# MCP Auth Server

인증 + 사용 통계 기능이 내장된 MCP 서버입니다.

## 실행

```bash
cd server
npm install
npm run dev
```

- MCP SSE: `http://localhost:3000/sse`
- Admin UI: `http://localhost:3000/admin`

## Claude Desktop 연동

`%APPDATA%\Claude\claude_desktop_config.json` 파일에 아래 내용 추가:

```json
{
  "mcpServers": {
    "my-mcp": {
      "url": "http://localhost:3000/sse",
      "headers": {
        "X-Api-Key": "usr_발급받은키"
      }
    }
  }
}
```

## 환경변수 (server/.env)

| 변수 | 기본값 | 설명 |
|------|--------|------|
| `PORT` | `3000` | 서버 포트 |
| `ADMIN_KEY` | `admin-secret-change-me` | Admin UI 로그인 키 **(반드시 변경)** |
| `DB_PATH` | `./data/mcp.db` | SQLite DB 경로 |

## 제공 Tool (샘플)

| Tool | 설명 |
|------|------|
| `echo` | 메시지를 그대로 반환 |
| `get_datetime` | 현재 날짜/시간 반환 (타임존 지원) |
| `calculate` | 사칙연산 |
| `random_number` | 범위 내 무작위 숫자 생성 |

## 인증 방식

- API Key는 Admin UI에서 발급 (`+ 사용자 추가`)
- 모든 요청에 `X-Api-Key` 헤더 자동 포함
- 비인가/비활성 사용자는 즉시 연결 거부
