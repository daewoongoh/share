/* ──────────────────────────────────────────────────────────
   MCP Admin Dashboard – app.js
────────────────────────────────────────────────────────── */

const API_BASE = window.location.origin;
let ADMIN_KEY = '';
let trendChart = null;
let toolChart  = null;

/* ── Helpers ─────────────────────────────────────────────── */
async function api(path, opts = {}) {
  const res = await fetch(`${API_BASE}/api/admin${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      'X-Admin-Key': ADMIN_KEY,
      ...(opts.headers ?? {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!res.ok) throw await res.json();
  return res.json();
}

function fmt(n) {
  if (n == null) return '—';
  return Number(n).toLocaleString();
}
function fmtMs(n) {
  if (n == null) return '—';
  return `${Math.round(n)} ms`;
}
function fmtDate(s) {
  if (!s) return '—';
  return new Date(s).toLocaleString('ko-KR', { hour12: false });
}
function maskKey(k) {
  return k.slice(0, 8) + '…' + k.slice(-4);
}

/* ── Auth ────────────────────────────────────────────────── */
document.getElementById('login-btn').addEventListener('click', login);
document.getElementById('admin-key-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') login();
});

async function login() {
  const key = document.getElementById('admin-key-input').value.trim();
  if (!key) return;
  ADMIN_KEY = key;
  try {
    await api('/stats/summary');
    document.getElementById('login-overlay').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    loadAll();
  } catch {
    document.getElementById('login-error').classList.remove('hidden');
    ADMIN_KEY = '';
  }
}

document.getElementById('logout-btn').addEventListener('click', () => {
  ADMIN_KEY = '';
  location.reload();
});

/* ── Tabs ────────────────────────────────────────────────── */
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    document.getElementById(`tab-${tab}`).classList.remove('hidden');
    document.getElementById('page-title').textContent =
      { dashboard: '대시보드', users: '사용자 관리', logs: '사용 로그' }[tab];
    if (tab === 'dashboard') loadDashboard();
    if (tab === 'users')     loadUsers();
    if (tab === 'logs')      loadLogs();
  });
});

document.getElementById('refresh-btn').addEventListener('click', loadAll);

function loadAll() {
  const active = document.querySelector('.nav-item.active')?.dataset.tab;
  if (active === 'dashboard') loadDashboard();
  if (active === 'users')     loadUsers();
  if (active === 'logs')      loadLogs();
}

/* ── Dashboard ───────────────────────────────────────────── */
async function loadDashboard() {
  const [summary, trend, tools, byUser] = await Promise.all([
    api('/stats/summary'),
    api(`/stats/trend?days=${document.getElementById('trend-days').value}`),
    api(`/stats/by-tool?days=${document.getElementById('tool-days').value}`),
    api(`/stats/by-user?days=${document.getElementById('user-stat-days').value}`),
  ]);

  document.getElementById('s-total-calls').textContent  = fmt(summary.totalCalls);
  document.getElementById('s-today-calls').textContent  = fmt(summary.todayCalls);
  document.getElementById('s-active-users').textContent = fmt(summary.activeUsers);
  document.getElementById('s-total-users').textContent  = fmt(summary.totalUsers);
  document.getElementById('last-updated').textContent   = '업데이트: ' + new Date().toLocaleTimeString('ko-KR');

  renderTrendChart(trend);
  renderToolChart(tools);
  renderUserStatTable(byUser);
}

function renderTrendChart(data) {
  const ctx = document.getElementById('trend-chart').getContext('2d');
  if (trendChart) trendChart.destroy();
  trendChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.map(d => d.day),
      datasets: [{
        label: '일별 호출',
        data: data.map(d => d.calls),
        borderColor: '#7c3aed',
        backgroundColor: 'rgba(124,58,237,0.12)',
        tension: 0.4, fill: true, pointRadius: 4,
        pointBackgroundColor: '#a78bfa',
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#7070a0' } },
        y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#7070a0' }, beginAtZero: true },
      },
    },
  });
}

function renderToolChart(data) {
  const ctx = document.getElementById('tool-chart').getContext('2d');
  if (toolChart) toolChart.destroy();
  const COLORS = ['#7c3aed','#2563eb','#059669','#d97706','#dc2626'];
  toolChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: data.map(d => d.tool_name),
      datasets: [{
        data: data.map(d => d.calls),
        backgroundColor: COLORS,
        borderWidth: 2,
        borderColor: '#12121a',
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { color: '#e8e8f0', padding: 14, font: { size: 12 } } },
      },
    },
  });
}

function renderUserStatTable(data) {
  const tbody = document.querySelector('#user-stat-table tbody');
  tbody.innerHTML = data.map(r => `
    <tr>
      <td>${r.name}</td>
      <td style="color:var(--muted)">${r.email}</td>
      <td><span class="badge badge-purple">${fmt(r.calls)}</span></td>
      <td>${r.errors > 0 ? `<span class="badge badge-red">${r.errors}</span>` : '<span class="badge badge-green">0</span>'}</td>
      <td>${fmtMs(r.avg_ms)}</td>
    </tr>
  `).join('') || '<tr><td colspan="5" style="text-align:center;color:var(--muted)">데이터 없음</td></tr>';
}

/* Filter changes */
['trend-days','tool-days','user-stat-days'].forEach(id =>
  document.getElementById(id).addEventListener('change', loadDashboard)
);

/* ── Users ───────────────────────────────────────────────── */
async function loadUsers() {
  const users = await api('/users');
  const tbody = document.querySelector('#users-table tbody');
  tbody.innerHTML = users.map(u => `
    <tr>
      <td>${u.name}</td>
      <td style="color:var(--muted)">${u.email}</td>
      <td>
        <span class="key-chip" title="${u.api_key}" onclick="copyToClipboard('${u.api_key}')">${maskKey(u.api_key)}</span>
      </td>
      <td>
        <span class="badge ${u.is_active ? 'badge-green' : 'badge-red'}">
          ${u.is_active ? '활성' : '비활성'}
        </span>
      </td>
      <td style="color:var(--muted)">${fmtDate(u.created_at)}</td>
      <td>
        <div class="action-btns">
          <button class="btn btn-ghost btn-sm" onclick="handleToggle('${u.id}')">
            ${u.is_active ? '비활성화' : '활성화'}
          </button>
          <button class="btn btn-ghost btn-sm" onclick="handleRegenKey('${u.id}')">
            🔑 재발급
          </button>
        </div>
      </td>
    </tr>
  `).join('') || '<tr><td colspan="6" style="text-align:center;color:var(--muted)">사용자 없음</td></tr>';
}

async function handleToggle(id) {
  await api(`/users/${id}/toggle`, { method: 'PATCH' });
  loadUsers();
}

async function handleRegenKey(id) {
  const { api_key } = await api(`/users/${id}/regenerate-key`, { method: 'POST' });
  showKeyToast(api_key);
  loadUsers();
}

/* ── Add User Modal ──────────────────────────────────────── */
document.getElementById('add-user-btn').addEventListener('click', () =>
  document.getElementById('add-user-modal').classList.remove('hidden')
);
document.getElementById('cancel-add-user').addEventListener('click', () =>
  document.getElementById('add-user-modal').classList.add('hidden')
);
document.getElementById('confirm-add-user').addEventListener('click', async () => {
  const name  = document.getElementById('new-user-name').value.trim();
  const email = document.getElementById('new-user-email').value.trim();
  if (!name || !email) return;
  try {
    const user = await api('/users', { method: 'POST', body: { name, email } });
    document.getElementById('add-user-modal').classList.add('hidden');
    document.getElementById('new-user-name').value  = '';
    document.getElementById('new-user-email').value = '';
    showKeyToast(user.api_key);
    loadUsers();
  } catch (err) {
    alert(err.error ?? '오류 발생');
  }
});

/* ── Logs ────────────────────────────────────────────────── */
async function loadLogs() {
  const limit = document.getElementById('log-limit').value;
  const logs = await api(`/stats/logs?limit=${limit}`);
  const tbody = document.querySelector('#logs-table tbody');
  tbody.innerHTML = logs.map(l => `
    <tr>
      <td style="color:var(--muted);font-size:.82rem">${fmtDate(l.created_at)}</td>
      <td>${l.user_name}</td>
      <td><span class="badge badge-purple">${l.tool_name}</span></td>
      <td>${fmtMs(l.duration_ms)}</td>
      <td>
        <span class="badge ${l.status === 'success' ? 'badge-green' : 'badge-red'}">
          ${l.status === 'success' ? '성공' : '오류'}
        </span>
      </td>
    </tr>
  `).join('') || '<tr><td colspan="5" style="text-align:center;color:var(--muted)">로그 없음</td></tr>';
}

document.getElementById('log-limit').addEventListener('change', loadLogs);

/* ── Toast ───────────────────────────────────────────────── */
function showKeyToast(key) {
  document.getElementById('toast-key-value').textContent = key;
  document.getElementById('api-key-toast').classList.remove('hidden');
}
document.getElementById('copy-key-btn').addEventListener('click', () => {
  copyToClipboard(document.getElementById('toast-key-value').textContent);
});
document.getElementById('close-toast-btn').addEventListener('click', () =>
  document.getElementById('api-key-toast').classList.add('hidden')
);

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById('copy-key-btn');
    btn.textContent = '✓ 복사됨';
    setTimeout(() => (btn.textContent = '복사'), 1500);
  });
}
