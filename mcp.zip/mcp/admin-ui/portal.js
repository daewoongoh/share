/* -------------------------------------------------------
   MCP Portal – portal.js
------------------------------------------------------- */

const SERVER = window.location.origin;
let currentKey = '';
let keyVisible = false;

// ── Error messages ────────────────────────────────────
const ERROR_MSGS = {
  github_denied:    'GitHub 로그인을 취소했습니다.',
  invalid_state:    '보안 오류가 발생했습니다. 다시 시도해주세요.',
  account_disabled: '계정이 비활성화되었습니다. 관리자에게 문의하세요.',
  oauth_failed:     'GitHub 인증에 실패했습니다. 다시 시도해주세요.',
};

// ── Init ──────────────────────────────────────────────
async function init() {
  showLoading(true);

  // URL 에러 파라미터 처리
  const params = new URLSearchParams(location.search);
  const err = params.get('error');
  history.replaceState({}, '', '/portal'); // URL 정리

  try {
    const res = await fetch(`${SERVER}/api/portal/me`, { credentials: 'include' });
    if (!res.ok) throw new Error('not_authenticated');
    const { user, stats } = await res.json();
    renderPortal(user, stats);
    showScreen('portal');
  } catch {
    if (err) {
      document.getElementById('error-banner').textContent = ERROR_MSGS[err] ?? '오류가 발생했습니다.';
      document.getElementById('error-banner').classList.remove('hidden');
    }
    showScreen('landing');
  } finally {
    showLoading(false);
  }
}

function showScreen(name) {
  document.getElementById('landing').classList.add('hidden');
  document.getElementById('portal').classList.add('hidden');
  document.getElementById(name).classList.remove('hidden');
  // landing은 flex가 필요
  if (name === 'landing') document.getElementById('landing').style.display = 'flex';
}

function showLoading(on) {
  document.getElementById('loading').style.display = on ? 'flex' : 'none';
}

// ── Render portal ─────────────────────────────────────
function renderPortal(user, stats) {
  currentKey = user.api_key;

  // 헤더
  const avatar = document.getElementById('avatar');
  if (user.avatar_url) {
    avatar.src = user.avatar_url;
    avatar.style.display = 'block';
  } else {
    avatar.style.display = 'none';
  }
  document.getElementById('user-name').textContent =
    user.github_login ? `@${user.github_login}` : user.name;

  // 환영 메시지
  document.getElementById('welcome-title').textContent = `안녕하세요, ${user.name}님 👋`;

  // API Key (처음엔 숨김)
  keyVisible = false;
  renderKey();

  // 설정 코드 스니펫
  renderSnippets(currentKey);

  // 통계
  document.getElementById('stat-total').textContent = stats.total.toLocaleString();
  document.getElementById('stat-week').textContent  = stats.thisWeek.toLocaleString();
  document.getElementById('stat-month').textContent = stats.thisMonth.toLocaleString();
  renderToolBars(stats.byTool);
}

function renderKey() {
  const el = document.getElementById('api-key-text');
  el.textContent = keyVisible ? currentKey : mask(currentKey);
  document.getElementById('toggle-key-btn').textContent = keyVisible ? '🙈' : '👁';
}

function mask(key) {
  return key.slice(0, 8) + '•'.repeat(Math.max(0, key.length - 12)) + key.slice(-4);
}

function renderSnippets(key) {
  const base = window.location.origin;

  const claudeConfig = JSON.stringify({
    mcpServers: {
      'my-mcp': {
        url: `${base}/sse`,
        headers: { 'X-Api-Key': key }
      }
    }
  }, null, 2);

  const cursorConfig = JSON.stringify({
    name: 'my-mcp',
    url: `${base}/sse`,
    headers: { 'X-Api-Key': key }
  }, null, 2);

  const windsurfConfig = JSON.stringify({
    mcpServers: {
      'my-mcp': {
        serverUrl: `${base}/sse`,
        headers: { 'X-Api-Key': key }
      }
    }
  }, null, 2);

  document.getElementById('code-claude').textContent    = claudeConfig;
  document.getElementById('code-cursor').textContent    = cursorConfig;
  document.getElementById('code-windsurf').textContent  = windsurfConfig;
}

function renderToolBars(byTool) {
  const container = document.getElementById('tool-bars');
  const wrap = document.getElementById('tool-breakdown-wrap');

  if (!byTool || byTool.length === 0) {
    wrap.style.display = 'none';
    return;
  }
  wrap.style.display = 'block';
  const max = byTool[0].calls;
  container.innerHTML = byTool.map(t => `
    <div class="tool-bar-row">
      <div class="tool-bar-name">${t.tool_name}</div>
      <div class="tool-bar-track">
        <div class="tool-bar-fill" style="width:${Math.round((t.calls/max)*100)}%"></div>
      </div>
      <div class="tool-bar-count">${t.calls}</div>
    </div>
  `).join('');
}

// ── Events – Key ──────────────────────────────────────
document.getElementById('toggle-key-btn').addEventListener('click', () => {
  keyVisible = !keyVisible;
  renderKey();
});

document.getElementById('copy-key-btn').addEventListener('click', () => {
  navigator.clipboard.writeText(currentKey).then(() => {
    const fb = document.getElementById('copy-feedback');
    fb.classList.remove('hidden');
    setTimeout(() => fb.classList.add('hidden'), 2000);
  });
});

document.getElementById('regen-btn').addEventListener('click', async () => {
  if (!confirm('API Key를 재발급하면 기존 키는 즉시 무효화됩니다. 계속하시겠습니까?')) return;
  const res = await fetch(`${SERVER}/api/portal/regenerate-key`, {
    method: 'POST', credentials: 'include'
  });
  if (!res.ok) { alert('재발급 실패'); return; }
  const { api_key } = await res.json();
  currentKey = api_key;
  keyVisible = true;
  renderKey();
  renderSnippets(api_key);
});

// ── Events – Tabs ─────────────────────────────────────
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
    btn.classList.add('active');
    document.getElementById(`tab-${btn.dataset.target}`).classList.remove('hidden');
  });
});

document.querySelectorAll('.code-copy-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const text = document.getElementById(btn.dataset.target).textContent;
    navigator.clipboard.writeText(text).then(() => {
      btn.textContent = '✓ 복사됨';
      setTimeout(() => (btn.textContent = '복사'), 1500);
    });
  });
});

// ── Events – Logout ───────────────────────────────────
document.getElementById('logout-btn').addEventListener('click', async () => {
  await fetch(`${SERVER}/api/portal/logout`, { method: 'POST', credentials: 'include' });
  location.reload();
});

// ── Boot ──────────────────────────────────────────────
init();
