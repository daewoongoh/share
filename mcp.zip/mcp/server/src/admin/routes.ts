import { Router, Request, Response } from 'express';
import {
  listUsers,
  createUser,
  toggleUser,
  regenerateKey,
} from '../auth/keyManager.js';
import {
  getStatsSummary,
  getStatsByUser,
  getStatsByTool,
  getDailyTrend,
  getRecentLogs,
} from '../stats/logger.js';

export function createAdminRouter(): Router {
  const router = Router();

  /* ── Admin Auth Middleware ── */
  router.use((req, res, next) => {
    const key = req.headers['x-admin-key'];
    if (key !== process.env.ADMIN_KEY) {
      res.status(401).json({ error: 'Invalid admin key' });
      return;
    }
    next();
  });

  /* ── Users ── */
  router.get('/users', (_req: Request, res: Response) => {
    res.json(listUsers());
  });

  router.post('/users', (req: Request, res: Response) => {
    const { name, email } = req.body;
    if (!name || !email) {
      res.status(400).json({ error: 'name, email 필수' });
      return;
    }
    try {
      const user = createUser(name, email);
      res.status(201).json(user);
    } catch (err: any) {
      res.status(409).json({ error: err.message });
    }
  });

  router.patch('/users/:id/toggle', (req: Request, res: Response) => {
    toggleUser(req.params.id);
    res.json({ ok: true });
  });

  router.post('/users/:id/regenerate-key', (req: Request, res: Response) => {
    const newKey = regenerateKey(req.params.id);
    res.json({ api_key: newKey });
  });

  /* ── Stats ── */
  router.get('/stats/summary', (_req: Request, res: Response) => {
    res.json(getStatsSummary());
  });

  router.get('/stats/by-user', (req: Request, res: Response) => {
    const days = Number(req.query.days) || 7;
    res.json(getStatsByUser(days));
  });

  router.get('/stats/by-tool', (req: Request, res: Response) => {
    const days = Number(req.query.days) || 7;
    res.json(getStatsByTool(days));
  });

  router.get('/stats/trend', (req: Request, res: Response) => {
    const days = Number(req.query.days) || 14;
    res.json(getDailyTrend(days));
  });

  router.get('/stats/logs', (req: Request, res: Response) => {
    const limit = Number(req.query.limit) || 100;
    res.json(getRecentLogs(limit));
  });

  return router;
}
