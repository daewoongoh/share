import { randomBytes } from 'crypto';
import type { Request, Response } from 'express';
import { findOrCreateGithubUser } from './keyManager.js';
import { createPortalSession } from './session.js';

// CSRF state 저장 (in-memory, TTL 5분)
const oauthStates = new Map<string, number>();

function cleanStates() {
  const now = Date.now();
  for (const [k, v] of oauthStates) if (v < now) oauthStates.delete(k);
}

export function handleGithubLogin(req: Request, res: Response): void {
  const clientId = process.env.GITHUB_CLIENT_ID;
  if (!clientId || clientId === 'your_github_client_id') {
    res.status(501).send(`
      <html><body style="font:16px sans-serif;padding:40px;background:#0a0a0f;color:#e8e8f0">
        <h2>⚠️ GitHub OAuth 미설정</h2>
        <p>서버 관리자에게 <code>.env</code>의 <code>GITHUB_CLIENT_ID</code> / <code>GITHUB_CLIENT_SECRET</code> 설정을 요청하세요.</p>
        <p><a href="/portal" style="color:#7c3aed">← 돌아가기</a></p>
      </body></html>
    `);
    return;
  }

  cleanStates();
  const state = randomBytes(16).toString('hex');
  oauthStates.set(state, Date.now() + 5 * 60 * 1000);

  const callbackUrl = process.env.GITHUB_CALLBACK_URL
    ?? `http://localhost:${process.env.PORT ?? 3000}/auth/github/callback`;

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: callbackUrl,
    scope: 'user:email',
    state,
  });
  res.redirect(`https://github.com/login/oauth/authorize?${params}`);
}

export async function handleGithubCallback(req: Request, res: Response): Promise<void> {
  const { code, state, error } = req.query as Record<string, string>;

  if (error) {
    res.redirect('/portal?error=github_denied');
    return;
  }

  const stateExpiry = oauthStates.get(state ?? '');
  if (!stateExpiry || stateExpiry < Date.now()) {
    res.redirect('/portal?error=invalid_state');
    return;
  }
  oauthStates.delete(state);

  try {
    const callbackUrl = process.env.GITHUB_CALLBACK_URL
      ?? `http://localhost:${process.env.PORT ?? 3000}/auth/github/callback`;

    // 1) code → access_token 교환
    const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: process.env.GITHUB_CLIENT_ID,
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code,
        redirect_uri: callbackUrl,
      }),
    });
    const tokenData = await tokenRes.json() as Record<string, string>;
    if (!tokenData.access_token) throw new Error('access_token 발급 실패');

    const authHeader = { Authorization: `Bearer ${tokenData.access_token}`, 'User-Agent': 'MCP-Auth-Server' };

    // 2) GitHub 사용자 정보 조회
    const [userRes, emailsRes] = await Promise.all([
      fetch('https://api.github.com/user', { headers: authHeader }),
      fetch('https://api.github.com/user/emails', { headers: authHeader }),
    ]);
    const githubUser = await userRes.json() as Record<string, unknown>;
    const emails = await emailsRes.json() as Array<{ email: string; primary: boolean }>;

    const primaryEmail = (githubUser.email as string | null)
      ?? emails.find(e => e.primary)?.email
      ?? emails[0]?.email
      ?? `${githubUser.login}@github.local`;

    // 3) 사용자 찾거나 생성
    const user = findOrCreateGithubUser({
      github_id:    String(githubUser.id),
      github_login: githubUser.login as string,
      name:         (githubUser.name as string | null) ?? (githubUser.login as string),
      email:        primaryEmail,
      avatar_url:   githubUser.avatar_url as string,
    });

    if (!user.is_active) {
      res.redirect('/portal?error=account_disabled');
      return;
    }

    // 4) 포털 세션 생성 (HttpOnly 쿠키)
    const sessionToken = createPortalSession(user.id);
    res.cookie('portal_session', sessionToken, {
      httpOnly: true,
      maxAge: 2 * 60 * 60 * 1000,
      sameSite: 'lax',
    });
    res.redirect('/portal');

  } catch (err) {
    console.error('[GitHub OAuth]', err);
    res.redirect('/portal?error=oauth_failed');
  }
}
