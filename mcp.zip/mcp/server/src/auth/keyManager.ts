import { randomBytes } from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { getDb } from '../db/client.js';

export interface User {
  id: string;
  name: string;
  email: string;
  api_key: string;
  is_active: number;
  github_id?: string;
  github_login?: string;
  avatar_url?: string;
  created_at: string;
}

/** prefix + 40 random hex chars */
function generateApiKey(): string {
  return 'usr_' + randomBytes(20).toString('hex');
}

export function createUser(name: string, email: string): User {
  const db = getDb();
  const user: User = {
    id: uuidv4(),
    name,
    email,
    api_key: generateApiKey(),
    is_active: 1,
    created_at: new Date().toISOString(),
  };
  db.prepare(
    `INSERT INTO users (id, name, email, api_key, is_active, created_at)
     VALUES (@id, @name, @email, @api_key, @is_active, @created_at)`
  ).run(user);
  return user;
}

export function findOrCreateGithubUser(gh: {
  github_id: string;
  github_login: string;
  name: string;
  email: string;
  avatar_url: string;
}): User {
  const db = getDb();

  // 1) GitHub ID로 기존 사용자 검색
  let user = db.prepare('SELECT * FROM users WHERE github_id = ?').get(gh.github_id) as User | undefined;
  if (user) {
    // 프로필 최신화
    db.prepare(`UPDATE users SET name=?, email=?, github_login=?, avatar_url=? WHERE id=?`)
      .run(gh.name, gh.email, gh.github_login, gh.avatar_url, user.id);
    return { ...user, name: gh.name, email: gh.email, github_login: gh.github_login, avatar_url: gh.avatar_url };
  }

  // 2) 이메일이 이미 있으면 GitHub 연동
  user = db.prepare('SELECT * FROM users WHERE email = ?').get(gh.email) as User | undefined;
  if (user) {
    db.prepare(`UPDATE users SET github_id=?, github_login=?, avatar_url=? WHERE id=?`)
      .run(gh.github_id, gh.github_login, gh.avatar_url, user.id);
    return { ...user, github_id: gh.github_id, github_login: gh.github_login, avatar_url: gh.avatar_url };
  }

  // 3) 신규 사용자 생성
  const newUser: User & { github_id: string; github_login: string; avatar_url: string } = {
    id: uuidv4(),
    name: gh.name,
    email: gh.email,
    api_key: generateApiKey(),
    is_active: 1,
    github_id: gh.github_id,
    github_login: gh.github_login,
    avatar_url: gh.avatar_url,
    created_at: new Date().toISOString(),
  };
  db.prepare(`
    INSERT INTO users (id, name, email, api_key, is_active, github_id, github_login, avatar_url, created_at)
    VALUES (@id, @name, @email, @api_key, @is_active, @github_id, @github_login, @avatar_url, @created_at)
  `).run(newUser);
  return newUser;
}

export function getUserByApiKey(apiKey: string): User | undefined {
  return getDb()
    .prepare('SELECT * FROM users WHERE api_key = ?')
    .get(apiKey) as User | undefined;
}

export function listUsers(): User[] {
  return getDb().prepare('SELECT * FROM users ORDER BY created_at DESC').all() as User[];
}

export function toggleUser(id: string): void {
  getDb().prepare(
    'UPDATE users SET is_active = CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id = ?'
  ).run(id);
}

export function regenerateKey(id: string): string {
  const newKey = generateApiKey();
  getDb().prepare('UPDATE users SET api_key = ? WHERE id = ?').run(newKey, id);
  return newKey;
}
