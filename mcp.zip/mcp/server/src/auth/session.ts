import { randomBytes } from 'crypto';
import { getDb } from '../db/client.js';

export function createPortalSession(userId: string): string {
  const db = getDb();
  const token = randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(); // 2시간

  db.prepare(
    'INSERT INTO portal_sessions (token, user_id, expires_at) VALUES (?, ?, ?)'
  ).run(token, userId, expiresAt);

  return token;
}

export function getSessionUser(token: string): Record<string, unknown> | null {
  const db = getDb();
  const session = db.prepare(
    "SELECT * FROM portal_sessions WHERE token = ? AND expires_at > datetime('now')"
  ).get(token) as { user_id: string } | undefined;

  if (!session) return null;

  return db.prepare(
    'SELECT * FROM users WHERE id = ? AND is_active = 1'
  ).get(session.user_id) as Record<string, unknown> | null;
}

export function deleteSession(token: string): void {
  getDb().prepare('DELETE FROM portal_sessions WHERE token = ?').run(token);
}

export function cleanExpiredSessions(): void {
  getDb().prepare("DELETE FROM portal_sessions WHERE expires_at <= datetime('now')").run();
}
