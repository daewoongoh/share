import { getDb } from './client.js';

export function initSchema(): void {
  const db = getDb();

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            TEXT PRIMARY KEY,
      name          TEXT NOT NULL,
      email         TEXT UNIQUE NOT NULL,
      api_key       TEXT UNIQUE NOT NULL,
      is_active     INTEGER NOT NULL DEFAULT 1,
      github_id     TEXT UNIQUE,
      github_login  TEXT,
      avatar_url    TEXT,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS usage_logs (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id     TEXT NOT NULL,
      tool_name   TEXT NOT NULL,
      arguments   TEXT,
      duration_ms INTEGER,
      status      TEXT NOT NULL DEFAULT 'success',
      error_msg   TEXT,
      created_at  TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS portal_sessions (
      token      TEXT PRIMARY KEY,
      user_id    TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE INDEX IF NOT EXISTS idx_usage_user   ON usage_logs(user_id);
    CREATE INDEX IF NOT EXISTS idx_usage_tool   ON usage_logs(tool_name);
    CREATE INDEX IF NOT EXISTS idx_usage_time   ON usage_logs(created_at);
    CREATE INDEX IF NOT EXISTS idx_session_exp  ON portal_sessions(expires_at);
  `);

  // 기존 DB 마이그레이션 (컬럼이 없으면 추가)
  const tryAlter = (sql: string) => { try { db.exec(sql); } catch {} };
  tryAlter('ALTER TABLE users ADD COLUMN github_id TEXT');
  tryAlter('ALTER TABLE users ADD COLUMN github_login TEXT');
  tryAlter('ALTER TABLE users ADD COLUMN avatar_url TEXT');
}
