import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';

import { initSchema } from './db/schema.js';
import { getUserByApiKey, regenerateKey } from './auth/keyManager.js';
import { createAdminRouter } from './admin/routes.js';
import { createMcpServer } from './tools/sampleTools.js';
import { handleGithubLogin, handleGithubCallback } from './auth/github.js';
import { getSessionUser, deleteSession, cleanExpiredSessions } from './auth/session.js';
import { getUserStats } from './stats/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ─── Init ──────────────────────────────────────────────────────────────────
initSchema();

const app = express();
app.use(cors());
app.use(express.json());
app.use(cookieParser());

// ─── Active SSE sessions ────────────────────────────────────────────────────
const sessions = new Map<string, SSEServerTransport>();

// ─── MCP SSE Endpoint ──────────────────────────────────────────────────────
app.get('/sse', async (req, res) => {
  const apiKey =
    (req.headers['x-api-key'] as string | undefined) ??
    (req.query.apiKey as string | undefined);

  if (!apiKey) {
    res.status(401).json({ error: 'API Key가 필요합니다 (X-Api-Key 헤더)' });
    return;
  }

  const user = getUserByApiKey(apiKey);
  if (!user) {
    res.status(401).json({ error: '유효하지 않은 API Key' });
    return;
  }
  if (!user.is_active) {
    res.status(403).json({ error: '비활성화된 계정입니다. 관리자에게 문의하세요.' });
    return;
  }

  console.log(`[SSE] 연결: ${user.name} (${user.email})`);

  const transport = new SSEServerTransport('/messages', res);
  sessions.set(transport.sessionId, transport);

  const mcpServer = createMcpServer(user);
  await mcpServer.connect(transport);

  req.on('close', () => {
    sessions.delete(transport.sessionId);
    console.log(`[SSE] 연결 종료: ${user.name}`);
  });
});

// ─── MCP POST Messages ─────────────────────────────────────────────────────
app.post('/messages', async (req, res) => {
  const sessionId = req.query.sessionId as string;
  const transport = sessions.get(sessionId);
  if (!transport) {
    res.status(404).json({ error: '세션을 찾을 수 없습니다' });
    return;
  }
  await transport.handlePostMessage(req, res);
});

// ─── GitHub OAuth ──────────────────────────────────────────────────────────
app.get('/auth/github', handleGithubLogin);
app.get('/auth/github/callback', handleGithubCallback);

// ─── Portal API ────────────────────────────────────────────────────────────
app.get('/api/portal/me', (req, res) => {
  const token = req.cookies?.portal_session;
  if (!token) { res.status(401).json({ error: 'not_authenticated' }); return; }

  const user = getSessionUser(token);
  if (!user) { res.status(401).json({ error: 'invalid_session' }); return; }

  const stats = getUserStats(user.id as string);
  res.json({ user, stats });
});

app.post('/api/portal/regenerate-key', (req, res) => {
  const token = req.cookies?.portal_session;
  if (!token) { res.status(401).json({ error: 'not_authenticated' }); return; }

  const user = getSessionUser(token);
  if (!user) { res.status(401).json({ error: 'invalid_session' }); return; }

  const newKey = regenerateKey(user.id as string);
  res.json({ api_key: newKey });
});

app.post('/api/portal/logout', (req, res) => {
  const token = req.cookies?.portal_session;
  if (token) {
    deleteSession(token);
    res.clearCookie('portal_session');
  }
  res.json({ ok: true });
});

// ─── Admin API ─────────────────────────────────────────────────────────────
app.use('/api/admin', createAdminRouter());

// ─── Static Files ──────────────────────────────────────────────────────────
const adminUiPath = path.join(__dirname, '../../admin-ui');
app.use('/admin', express.static(adminUiPath));
app.get('/admin', (_req, res) => res.sendFile(path.join(adminUiPath, 'index.html')));
app.get('/portal', (_req, res) => res.sendFile(path.join(adminUiPath, 'portal.html')));

// ─── Health Check ──────────────────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', mcpSessions: sessions.size, time: new Date().toISOString() });
});

// ─── Cleanup expired sessions (매 30분) ────────────────────────────────────
setInterval(cleanExpiredSessions, 30 * 60 * 1000);

// ─── Start ─────────────────────────────────────────────────────────────────
const PORT = Number(process.env.PORT ?? 3000);
app.listen(PORT, () => {
  console.log(`
╔═════════════════════════════════════════════╗
║        MCP Auth Server Started              ║
╠═════════════════════════════════════════════╣
║  MCP   : http://localhost:${PORT}/sse           ║
║  Portal: http://localhost:${PORT}/portal        ║
║  Admin : http://localhost:${PORT}/admin         ║
╚═════════════════════════════════════════════╝
  `);
});
