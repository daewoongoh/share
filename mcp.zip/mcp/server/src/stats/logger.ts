import { getDb } from '../db/client.js';

export interface UsageLog {
  user_id: string;
  tool_name: string;
  arguments?: string;
  duration_ms?: number;
  status: 'success' | 'error';
  error_msg?: string;
}

export function logUsage(entry: UsageLog): void {
  getDb().prepare(`
    INSERT INTO usage_logs (user_id, tool_name, arguments, duration_ms, status, error_msg)
    VALUES (@user_id, @tool_name, @arguments, @duration_ms, @status, @error_msg)
  `).run(entry);
}

export function getStatsSummary() {
  const db = getDb();
  return {
    totalCalls: (db.prepare('SELECT COUNT(*) as c FROM usage_logs').get() as any).c,
    totalUsers: (db.prepare('SELECT COUNT(*) as c FROM users').get() as any).c,
    activeUsers: (db.prepare('SELECT COUNT(*) as c FROM users WHERE is_active=1').get() as any).c,
    todayCalls: (db.prepare(
      "SELECT COUNT(*) as c FROM usage_logs WHERE date(created_at)=date('now')"
    ).get() as any).c,
  };
}

export function getStatsByUser(days = 7) {
  return getDb().prepare(`
    SELECT u.name, u.email, COUNT(l.id) as calls,
           SUM(CASE WHEN l.status='error' THEN 1 ELSE 0 END) as errors,
           AVG(l.duration_ms) as avg_ms
    FROM users u
    LEFT JOIN usage_logs l ON l.user_id = u.id
      AND l.created_at >= datetime('now', '-${days} days')
    GROUP BY u.id
    ORDER BY calls DESC
  `).all();
}

export function getStatsByTool(days = 7) {
  return getDb().prepare(`
    SELECT tool_name, COUNT(*) as calls,
           SUM(CASE WHEN status='error' THEN 1 ELSE 0 END) as errors,
           AVG(duration_ms) as avg_ms
    FROM usage_logs
    WHERE created_at >= datetime('now', '-${days} days')
    GROUP BY tool_name
    ORDER BY calls DESC
  `).all();
}

export function getDailyTrend(days = 14) {
  return getDb().prepare(`
    SELECT date(created_at) as day, COUNT(*) as calls
    FROM usage_logs
    WHERE created_at >= datetime('now', '-${days} days')
    GROUP BY day
    ORDER BY day ASC
  `).all();
}

export function getRecentLogs(limit = 100) {
  return getDb().prepare(`
    SELECT l.*, u.name as user_name, u.email
    FROM usage_logs l
    JOIN users u ON u.id = l.user_id
    ORDER BY l.created_at DESC
    LIMIT ?
  `).all(limit);
}

export function getUserStats(userId: string) {
  const db = getDb();
  const q = (sql: string) => (db.prepare(sql).get(userId) as any).c as number;
  return {
    total:     q('SELECT COUNT(*) as c FROM usage_logs WHERE user_id=?'),
    thisWeek:  q("SELECT COUNT(*) as c FROM usage_logs WHERE user_id=? AND created_at >= datetime('now','-7 days')"),
    thisMonth: q("SELECT COUNT(*) as c FROM usage_logs WHERE user_id=? AND created_at >= datetime('now','-30 days')"),
    byTool: db.prepare(
      'SELECT tool_name, COUNT(*) as calls FROM usage_logs WHERE user_id=? GROUP BY tool_name ORDER BY calls DESC'
    ).all(userId) as Array<{ tool_name: string; calls: number }>,
  };
}
