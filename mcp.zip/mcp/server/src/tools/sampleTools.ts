import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { logUsage } from '../stats/logger.js';
import type { User } from '../auth/keyManager.js';

// ─── Tool Definitions ──────────────────────────────────────────────────────

const TOOL_DEFS = [
  {
    name: 'echo',
    description: '입력한 메시지를 그대로 돌려줍니다.',
    inputSchema: {
      type: 'object',
      properties: {
        message: { type: 'string', description: '돌려줄 메시지' },
      },
      required: ['message'],
    },
  },
  {
    name: 'get_datetime',
    description: '현재 날짜와 시간을 반환합니다.',
    inputSchema: {
      type: 'object',
      properties: {
        timezone: {
          type: 'string',
          description: 'IANA 타임존 (예: Asia/Seoul). 기본값: UTC',
        },
      },
    },
  },
  {
    name: 'calculate',
    description: '기본 사칙연산을 수행합니다.',
    inputSchema: {
      type: 'object',
      properties: {
        a: { type: 'number', description: '첫 번째 숫자' },
        b: { type: 'number', description: '두 번째 숫자' },
        op: {
          type: 'string',
          enum: ['add', 'subtract', 'multiply', 'divide'],
          description: '연산 종류',
        },
      },
      required: ['a', 'b', 'op'],
    },
  },
  {
    name: 'random_number',
    description: '지정한 범위 안에서 무작위 숫자를 생성합니다.',
    inputSchema: {
      type: 'object',
      properties: {
        min: { type: 'number', description: '최솟값 (기본: 1)' },
        max: { type: 'number', description: '최댓값 (기본: 100)' },
      },
    },
  },
] as const;

// ─── Tool Handlers ─────────────────────────────────────────────────────────

function handleEcho(args: Record<string, unknown>) {
  return `Echo: ${args.message}`;
}

function handleDatetime(args: Record<string, unknown>) {
  const tz = (args.timezone as string | undefined) ?? 'UTC';
  try {
    return new Date().toLocaleString('ko-KR', { timeZone: tz, hour12: false });
  } catch {
    return new Date().toISOString();
  }
}

function handleCalculate(args: Record<string, unknown>) {
  const a = args.a as number;
  const b = args.b as number;
  const op = args.op as string;
  let result: number;
  switch (op) {
    case 'add':      result = a + b; break;
    case 'subtract': result = a - b; break;
    case 'multiply': result = a * b; break;
    case 'divide':
      if (b === 0) throw new Error('0으로 나눌 수 없습니다');
      result = a / b;
      break;
    default: throw new Error(`알 수 없는 연산: ${op}`);
  }
  return `${a} ${op} ${b} = ${result}`;
}

function handleRandom(args: Record<string, unknown>) {
  const min = (args.min as number | undefined) ?? 1;
  const max = (args.max as number | undefined) ?? 100;
  const val = Math.floor(Math.random() * (max - min + 1)) + min;
  return `무작위 숫자 (${min}~${max}): ${val}`;
}

// ─── Server Factory ────────────────────────────────────────────────────────

export function createMcpServer(user: User): Server {
  const server = new Server(
    { name: 'mcp-auth-server', version: '1.0.0' },
    { capabilities: { tools: {} } }
  );

  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: TOOL_DEFS,
  }));

  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const { name, arguments: args = {} } = req.params;
    const start = Date.now();
    let status: 'success' | 'error' = 'success';
    let errorMsg: string | undefined;
    let resultText = '';

    try {
      switch (name) {
        case 'echo':         resultText = handleEcho(args as Record<string, unknown>); break;
        case 'get_datetime': resultText = handleDatetime(args as Record<string, unknown>); break;
        case 'calculate':    resultText = handleCalculate(args as Record<string, unknown>); break;
        case 'random_number': resultText = handleRandom(args as Record<string, unknown>); break;
        default: throw new Error(`알 수 없는 Tool: ${name}`);
      }
    } catch (err) {
      status = 'error';
      errorMsg = err instanceof Error ? err.message : String(err);
      resultText = `오류: ${errorMsg}`;
    } finally {
      logUsage({
        user_id: user.id,
        tool_name: name,
        arguments: JSON.stringify(args),
        duration_ms: Date.now() - start,
        status,
        error_msg: errorMsg,
      });
    }

    return {
      content: [{ type: 'text', text: resultText }],
      isError: status === 'error',
    };
  });

  return server;
}
